exports.TOKEN = "your bot token";

exports.PREFIX = 'YOUR PREFIX';

exports.OWNER_ID = "YOUR ACC ID"